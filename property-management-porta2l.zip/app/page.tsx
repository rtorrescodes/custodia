import { AppShell } from "@/components/app-shell"
import { KpiCards } from "@/components/dashboard/kpi-cards"
import { WorkOrdersTable } from "@/components/dashboard/work-orders-table"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { StatusBadge } from "@/components/status-badge"
import { Cable, CircleCheck, CircleX } from "lucide-react"
import { dashboardData } from "@/lib/data"

const integraciones = [
  { nombre: "Alddea", ok: true, descripcion: "Domótica y control de accesos" },
  { nombre: "RAVSIS", ok: false, descripcion: "Videovigilancia" },
  { nombre: "Stripe", ok: true, descripcion: "Cobros y trust accounting" },
]

const proximas = [
  { propiedad: "Torre Marena PH2", tarea: "Inspección estructural", estado: "pendiente" as const },
  { propiedad: "Residencial Aurora 4B", tarea: "Cambio de luminarias", estado: "en-progreso" as const },
  { propiedad: "Casa Bugambilias 7", tarea: "Fumigación programada", estado: "pendiente" as const },
]

export default function DashboardPage() {
  const { usuario, kpis, ordenesRecientes } = dashboardData

  return (
    <AppShell
      title={`Buen día, ${usuario.nombre.split(" ")[0]}`}
      breadcrumb="Inicio / Dashboard"
      usuario={usuario}
      alertas={kpis.alertasCriticas}
    >
      <div className="flex flex-col gap-6">
        <KpiCards kpis={kpis} />

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <div className="xl:col-span-2">
            <WorkOrdersTable ordenes={ordenesRecientes} />
          </div>

          <div className="flex flex-col gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base font-semibold">
                  <Cable className="size-4 text-primary" />
                  Integraciones activas
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                {integraciones.map((i) => (
                  <div
                    key={i.nombre}
                    className="flex items-center justify-between rounded-xl border border-border p-3"
                  >
                    <div>
                      <p className="text-sm font-semibold text-foreground">{i.nombre}</p>
                      <p className="text-xs text-muted-foreground">{i.descripcion}</p>
                    </div>
                    {i.ok ? (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
                        <CircleCheck className="size-4" /> Activa
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-destructive">
                        <CircleX className="size-4" /> Error
                      </span>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base font-semibold">Próximas tareas</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                {proximas.map((t, idx) => (
                  <div key={idx} className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-foreground">{t.tarea}</p>
                      <p className="truncate text-xs text-muted-foreground">{t.propiedad}</p>
                    </div>
                    <StatusBadge estado={t.estado} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  )
}
