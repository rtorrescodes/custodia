import Link from "next/link"
import { Building2, ChevronLeft } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { LedgerView } from "@/components/portal/ledger-view"
import { ledgerData } from "@/lib/data"

export default function PortalPage() {
  return (
    <div className="min-h-svh bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between gap-3 px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <Building2 className="size-5" />
            </div>
            <div className="leading-tight">
              <span className="text-base font-bold text-foreground">Ribera</span>
              <span className="ml-2 rounded-md bg-accent/60 px-1.5 py-0.5 text-xs font-medium text-accent-foreground">
                Portal del Dueño
              </span>
            </div>
          </Link>
          <Avatar className="size-9">
            <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">RS</AvatarFallback>
          </Avatar>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl px-4 py-6 md:px-6 md:py-8">
        <Link
          href="/"
          className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ChevronLeft className="size-4" /> Volver
        </Link>
        <div className="mb-6 flex flex-col gap-1">
          <h1 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">Estado de cuenta</h1>
          <p className="text-sm text-muted-foreground">
            Villa Palmar 12 · Transparencia total de los movimientos de tu propiedad.
          </p>
        </div>
        <LedgerView data={ledgerData} />
      </main>
    </div>
  )
}
