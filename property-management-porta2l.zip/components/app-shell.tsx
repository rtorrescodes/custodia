"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Home,
  Building2,
  Wrench,
  Wallet,
  Cable,
  Settings,
  Search,
  Bell,
  Menu,
  PanelLeftClose,
  ChevronDown,
  LogOut,
  UserRound,
  ShieldAlert,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const nav = [
  { label: "Inicio", href: "/", icon: Home },
  { label: "Propiedades", href: "/propiedades/PROP-0012", icon: Building2 },
  { label: "Mantenimiento", href: "/mantenimiento", icon: Wrench },
  { label: "Finanzas", href: "/portal", icon: Wallet },
  { label: "Integraciones", href: "/integraciones", icon: Cable },
  { label: "Configuración", href: "/configuracion", icon: Settings },
]

function isActive(pathname: string, href: string) {
  if (href === "/") return pathname === "/"
  if (href.startsWith("/propiedades")) return pathname.startsWith("/propiedades")
  return pathname === href || pathname.startsWith(href + "/")
}

function SidebarContent({ collapsed }: { collapsed: boolean }) {
  const pathname = usePathname()
  return (
    <div className="flex h-full flex-col">
      <div className={cn("flex h-16 items-center gap-3 px-5", collapsed && "justify-center px-0")}>
        <div className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Building2 className="size-5" />
        </div>
        {!collapsed && <span className="text-lg font-bold tracking-tight text-foreground">Ribera</span>}
      </div>

      <nav className="flex flex-1 flex-col gap-1 px-3 py-4">
        {nav.map((item) => {
          const active = isActive(pathname, item.href)
          return (
            <Link
              key={item.label}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                collapsed && "justify-center px-0",
                active
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
              )}
              title={collapsed ? item.label : undefined}
            >
              <item.icon className="size-5 shrink-0" />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          )
        })}
      </nav>

      <div className="p-3">
        <div
          className={cn(
            "rounded-2xl bg-accent/60 p-4",
            collapsed && "flex justify-center bg-transparent p-2",
          )}
        >
          {collapsed ? (
            <ShieldAlert className="size-5 text-primary" />
          ) : (
            <>
              <div className="flex items-center gap-2">
                <ShieldAlert className="size-4 text-primary" />
                <p className="text-sm font-semibold text-foreground">Plan Enterprise</p>
              </div>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                Soporte prioritario y trust accounting ilimitado.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export function AppShell({
  children,
  title,
  breadcrumb,
  usuario,
  alertas = 0,
}: {
  children: React.ReactNode
  title: string
  breadcrumb?: string
  usuario: { nombre: string; rol: string }
  alertas?: number
}) {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const iniciales = usuario.nombre
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")

  return (
    <div className="flex min-h-svh bg-background">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "sticky top-0 hidden h-svh shrink-0 border-r border-sidebar-border bg-sidebar transition-[width] duration-200 lg:block",
          collapsed ? "w-[76px]" : "w-64",
        )}
      >
        <SidebarContent collapsed={collapsed} />
      </aside>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-foreground/40" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-64 border-r border-sidebar-border bg-sidebar">
            <SidebarContent collapsed={false} />
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-md md:px-6">
          <Button
            variant="ghost"
            size="icon"
            className="hidden lg:inline-flex"
            onClick={() => setCollapsed((c) => !c)}
            aria-label="Colapsar menú"
          >
            <PanelLeftClose className={cn("size-5 transition-transform", collapsed && "rotate-180")} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Abrir menú"
          >
            <Menu className="size-5" />
          </Button>

          <div className="relative hidden max-w-md flex-1 md:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar propiedades, órdenes, dueños…"
              className="h-10 rounded-xl border-transparent bg-muted pl-9"
              aria-label="Buscar"
            />
          </div>

          <div className="ml-auto flex items-center gap-1.5">
            <Button variant="ghost" size="icon" className="relative rounded-xl" aria-label="Notificaciones">
              <Bell className="size-5" />
              {alertas > 0 && (
                <span className="absolute right-1.5 top-1.5 flex size-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-white">
                  {alertas}
                </span>
              )}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger className="ml-1 flex items-center gap-2 rounded-xl py-1 pl-1 pr-2 text-left transition-colors hover:bg-muted">
                <Avatar className="size-9">
                  <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">
                    {iniciales}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden leading-tight sm:block">
                  <p className="text-sm font-semibold text-foreground">{usuario.nombre}</p>
                  <p className="text-xs text-muted-foreground">{usuario.rol}</p>
                </div>
                <ChevronDown className="hidden size-4 text-muted-foreground sm:block" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem>
                    <UserRound className="size-4" />
                    Perfil
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="size-4" />
                    Preferencias
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem render={<Link href="/login" />}>
                  <LogOut className="size-4" />
                  Cerrar sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="flex-1 px-4 py-6 md:px-6 lg:px-8">
          <div className="mx-auto w-full max-w-7xl">
            <div className="mb-6 flex flex-col gap-1">
              {breadcrumb && (
                <p className="text-sm text-muted-foreground">{breadcrumb}</p>
              )}
              <h1 className="text-2xl font-bold tracking-tight text-foreground text-balance md:text-3xl">
                {title}
              </h1>
            </div>
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
