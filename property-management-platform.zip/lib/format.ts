import type { Currency, WorkOrderStatus } from './data'

export function formatMoney(amount: number, currency: Currency): string {
  return new Intl.NumberFormat(currency === 'USD' ? 'en-US' : 'es-MX', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatMoneyCompact(amount: number, currency: Currency): string {
  return new Intl.NumberFormat(currency === 'USD' ? 'en-US' : 'es-MX', {
    style: 'currency',
    currency,
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(amount)
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('es-MX', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

export const workOrderStatusLabel: Record<WorkOrderStatus, string> = {
  pendiente: 'Pendiente',
  en_progreso: 'En progreso',
  completada: 'Completada',
  cancelada: 'Cancelada',
}

// maps a work order status to a Badge className using semantic status tokens
export const workOrderStatusClass: Record<WorkOrderStatus, string> = {
  pendiente: 'bg-warning/15 text-warning-foreground border-warning/30',
  en_progreso: 'bg-info/12 text-info border-info/30',
  completada: 'bg-success/12 text-success border-success/30',
  cancelada: 'bg-muted text-muted-foreground border-border',
}
