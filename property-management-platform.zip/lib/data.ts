// Domain types + mock data source for the Property Management platform.
// In a real app these would be fetched from a database inside Server Components.

export type Currency = 'USD' | 'MXN'

export type WorkOrderStatus =
  | 'pendiente'
  | 'en_progreso'
  | 'completada'
  | 'cancelada'

export interface WorkOrder {
  id: string
  property: string
  propertyId: string
  assignee: string
  assigneeInitials: string
  status: WorkOrderStatus
  cost: number
  currency: Currency
  createdAt: string
}

export interface Kpi {
  totalProperties: number
  monthlyRevenueUsd: number
  monthlyRevenueMxn: number
  pendingWorkOrders: number
  criticalSecurityAlerts: number
  // trailing deltas for context (percent, month over month)
  revenueDeltaPct: number
  propertiesDelta: number
}

export interface DashboardProps {
  kpi: Kpi
  recentWorkOrders: WorkOrder[]
  managerName: string
  orgName: string
}

export interface CoOwner {
  id: string
  name: string
  initials: string
  sharePct: number
  email: string
}

export type IntegrationProvider = 'Alddea' | 'RAVSIS'
export type IntegrationStatus = 'conectado' | 'error' | 'desconectado'

export interface Integration {
  provider: IntegrationProvider
  status: IntegrationStatus
  description: string
  lastSync: string | null
}

export interface MaintenanceEntry {
  id: string
  date: string
  title: string
  vendor: string
  status: WorkOrderStatus
  cost: number
  currency: Currency
}

export interface LedgerEntry {
  id: string
  date: string
  type: 'ingreso' | 'egreso'
  category: string
  description: string
  amount: number
  currency: Currency
  hasReceipt: boolean
  approvalRequired?: boolean
  approvalStatus?: 'pendiente' | 'aprobado'
}

export interface PropertyPhoto {
  src: string
  alt: string
}

export interface Property {
  id: string
  name: string
  address: string
  fraccionamiento: string
  city: string
  type: string
  bedrooms: number
  bathrooms: number
  areaM2: number
  status: 'ocupada' | 'disponible' | 'mantenimiento'
  photos: PropertyPhoto[]
  amenities: string[]
  coOwners: CoOwner[]
  integrations: Integration[]
  maintenanceHistory: MaintenanceEntry[]
  ledger: LedgerEntry[]
}

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const workOrders: WorkOrder[] = [
  {
    id: 'OT-4821',
    property: 'Villa Coral 12',
    propertyId: 'prop-001',
    assignee: 'Miguel Ángel Torres',
    assigneeInitials: 'MT',
    status: 'pendiente',
    cost: 4800,
    currency: 'MXN',
    createdAt: '2026-08-14',
  },
  {
    id: 'OT-4820',
    property: 'Residencia Palma 3',
    propertyId: 'prop-002',
    assignee: 'Laura Jiménez',
    assigneeInitials: 'LJ',
    status: 'en_progreso',
    cost: 320,
    currency: 'USD',
    createdAt: '2026-08-13',
  },
  {
    id: 'OT-4818',
    property: 'Casa Encino 8',
    propertyId: 'prop-003',
    assignee: 'Servicios HVAC del Norte',
    assigneeInitials: 'SN',
    status: 'completada',
    cost: 12500,
    currency: 'MXN',
    createdAt: '2026-08-11',
  },
  {
    id: 'OT-4815',
    property: 'Villa Coral 12',
    propertyId: 'prop-001',
    assignee: 'Miguel Ángel Torres',
    assigneeInitials: 'MT',
    status: 'pendiente',
    cost: 1500,
    currency: 'MXN',
    createdAt: '2026-08-10',
  },
  {
    id: 'OT-4809',
    property: 'Loft Marina 21',
    propertyId: 'prop-004',
    assignee: 'Aqua Pool Care',
    assigneeInitials: 'AP',
    status: 'cancelada',
    cost: 210,
    currency: 'USD',
    createdAt: '2026-08-08',
  },
  {
    id: 'OT-4805',
    property: 'Residencia Palma 3',
    propertyId: 'prop-002',
    assignee: 'Electricidad Delta',
    assigneeInitials: 'ED',
    status: 'completada',
    cost: 6200,
    currency: 'MXN',
    createdAt: '2026-08-05',
  },
]

const property: Property = {
  id: 'prop-001',
  name: 'Villa Coral 12',
  address: 'Av. Paseo de los Corales 12, C.P. 63732',
  fraccionamiento: 'Fraccionamiento Bahía Marina',
  city: 'Nuevo Vallarta, Nayarit',
  type: 'Casa residencial',
  bedrooms: 4,
  bathrooms: 4.5,
  areaM2: 420,
  status: 'ocupada',
  photos: [
    { src: '/properties/casa-exterior.png', alt: 'Fachada exterior de Villa Coral 12' },
    { src: '/properties/casa-sala.png', alt: 'Sala principal de Villa Coral 12' },
    { src: '/properties/amenidad-alberca.png', alt: 'Alberca comunitaria del fraccionamiento' },
  ],
  amenities: [
    'Alberca comunitaria',
    'Acceso controlado 24/7',
    'Gimnasio',
    'Muelle privado',
    'Jardín paisajista',
    'Estacionamiento para 3 autos',
  ],
  coOwners: [
    {
      id: 'co-1',
      name: 'Carlos Mendoza',
      initials: 'CM',
      sharePct: 50,
      email: 'carlos.mendoza@email.com',
    },
    {
      id: 'co-2',
      name: 'Ana Sofía Rivera',
      initials: 'AR',
      sharePct: 30,
      email: 'ana.rivera@email.com',
    },
    {
      id: 'co-3',
      name: 'Grupo Inversiones del Pacífico',
      initials: 'GP',
      sharePct: 20,
      email: 'contacto@invpacifico.mx',
    },
  ],
  integrations: [
    {
      provider: 'Alddea',
      status: 'conectado',
      description: 'Administración de cuotas y estados de cuenta',
      lastSync: 'Hace 12 min',
    },
    {
      provider: 'RAVSIS',
      status: 'error',
      description: 'Control de acceso y seguridad perimetral',
      lastSync: 'Hace 6 h',
    },
  ],
  maintenanceHistory: [
    {
      id: 'OT-4821',
      date: '2026-08-14',
      title: 'Fuga en tubería de baño principal',
      vendor: 'Miguel Ángel Torres',
      status: 'pendiente',
      cost: 4800,
      currency: 'MXN',
    },
    {
      id: 'OT-4815',
      date: '2026-08-10',
      title: 'Mantenimiento de aire acondicionado',
      vendor: 'Servicios HVAC del Norte',
      status: 'pendiente',
      cost: 1500,
      currency: 'MXN',
    },
    {
      id: 'OT-4790',
      date: '2026-07-28',
      title: 'Poda y jardinería mensual',
      vendor: 'Jardines Verdes',
      status: 'completada',
      cost: 2200,
      currency: 'MXN',
    },
    {
      id: 'OT-4771',
      date: '2026-07-15',
      title: 'Reparación de bomba de alberca',
      vendor: 'Aqua Pool Care',
      status: 'completada',
      cost: 380,
      currency: 'USD',
    },
  ],
  ledger: [
    {
      id: 'tx-1',
      date: '2026-08-15',
      type: 'ingreso',
      category: 'Renta',
      description: 'Renta mensual agosto',
      amount: 3200,
      currency: 'USD',
      hasReceipt: true,
    },
    {
      id: 'tx-2',
      date: '2026-08-14',
      type: 'egreso',
      category: 'Mantenimiento',
      description: 'Reparación tubería baño principal',
      amount: 4800,
      currency: 'MXN',
      hasReceipt: true,
      approvalRequired: true,
      approvalStatus: 'pendiente',
    },
    {
      id: 'tx-3',
      date: '2026-08-05',
      type: 'egreso',
      category: 'Servicios',
      description: 'CFE — recibo bimestral',
      amount: 1850,
      currency: 'MXN',
      hasReceipt: true,
    },
    {
      id: 'tx-4',
      date: '2026-08-01',
      type: 'egreso',
      category: 'Administración',
      description: 'Cuota de mantenimiento fraccionamiento',
      amount: 2400,
      currency: 'MXN',
      hasReceipt: true,
    },
  ],
}

// ---------------------------------------------------------------------------
// Data access helpers (async to mimic real Server Component fetching)
// ---------------------------------------------------------------------------

export async function getDashboardData(): Promise<DashboardProps> {
  return {
    managerName: 'Daniela Suárez',
    orgName: 'Atrio Property Group',
    kpi: {
      totalProperties: 148,
      monthlyRevenueUsd: 284_500,
      monthlyRevenueMxn: 5_120_000,
      pendingWorkOrders: 23,
      criticalSecurityAlerts: 3,
      revenueDeltaPct: 8.4,
      propertiesDelta: 6,
    },
    recentWorkOrders: workOrders,
  }
}

export async function getProperty(id: string): Promise<Property | null> {
  // single mock property; ignore id variations for the demo
  return { ...property, id }
}

export interface OwnerLedgerData {
  ownerName: string
  propertyName: string
  balance: number
  balanceCurrency: Currency
  monthIncome: number
  monthExpense: number
  transactions: LedgerEntry[]
}

export async function getOwnerLedger(): Promise<OwnerLedgerData> {
  return {
    ownerName: 'Carlos Mendoza',
    propertyName: 'Villa Coral 12',
    balance: 82_400,
    balanceCurrency: 'MXN',
    monthIncome: 3200,
    monthExpense: 9050,
    transactions: [
      {
        id: 'l-1',
        date: '2026-08-15',
        type: 'ingreso',
        category: 'Renta',
        description: 'Renta mensual agosto (huésped verificado)',
        amount: 3200,
        currency: 'USD',
        hasReceipt: true,
      },
      {
        id: 'l-2',
        date: '2026-08-14',
        type: 'egreso',
        category: 'Mantenimiento',
        description: 'Reparación tubería baño principal',
        amount: 4800,
        currency: 'MXN',
        hasReceipt: true,
        approvalRequired: true,
        approvalStatus: 'pendiente',
      },
      {
        id: 'l-3',
        date: '2026-08-10',
        type: 'egreso',
        category: 'Mantenimiento',
        description: 'Servicio de aire acondicionado',
        amount: 1500,
        currency: 'MXN',
        hasReceipt: false,
        approvalRequired: true,
        approvalStatus: 'pendiente',
      },
      {
        id: 'l-4',
        date: '2026-08-05',
        type: 'egreso',
        category: 'Servicios',
        description: 'CFE — recibo bimestral',
        amount: 1850,
        currency: 'MXN',
        hasReceipt: true,
      },
      {
        id: 'l-5',
        date: '2026-08-01',
        type: 'egreso',
        category: 'Administración',
        description: 'Cuota de mantenimiento del fraccionamiento',
        amount: 2400,
        currency: 'MXN',
        hasReceipt: true,
      },
    ],
  }
}
