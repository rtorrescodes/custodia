'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Building2,
  LayoutDashboard,
  Wrench,
  Wallet,
  Plug,
  Settings,
  ShieldCheck,
  UserRound,
} from 'lucide-react'

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar'
import { Badge } from '@/components/ui/badge'

const mainNav = [
  { title: 'Inicio', href: '/', icon: LayoutDashboard },
  { title: 'Propiedades', href: '/propiedades', icon: Building2 },
  { title: 'Mantenimiento', href: '/mantenimiento', icon: Wrench, badge: '23' },
  { title: 'Finanzas', href: '/finanzas', icon: Wallet },
  { title: 'Integraciones', href: '/integraciones', icon: Plug },
  { title: 'Configuración', href: '/configuracion', icon: Settings },
]

export function AppSidebar() {
  const pathname = usePathname()

  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname.startsWith(href)

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <div className="flex items-center gap-2.5 px-1 py-1.5">
          <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <ShieldCheck className="size-4" />
          </div>
          <div className="flex flex-col leading-tight group-data-[collapsible=icon]:hidden">
            <span className="text-sm font-semibold tracking-tight">Atrio</span>
            <span className="text-xs text-muted-foreground">Property Group</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Plataforma</SidebarGroupLabel>
          <SidebarMenu>
            {mainNav.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  isActive={isActive(item.href)}
                  tooltip={item.title}
                  render={<Link href={item.href} />}
                >
                  <item.icon />
                  <span>{item.title}</span>
                  {item.badge ? (
                    <Badge
                      variant="secondary"
                      className="ml-auto h-4 px-1.5 text-[10px] group-data-[collapsible=icon]:hidden"
                    >
                      {item.badge}
                    </Badge>
                  ) : null}
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Portales</SidebarGroupLabel>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton
                isActive={isActive('/portal')}
                tooltip="Portal de Dueño"
                render={<Link href="/portal" />}
              >
                <UserRound />
                <span>Portal de Dueño</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <div className="rounded-md border border-sidebar-border bg-sidebar-accent/50 p-3 text-xs group-data-[collapsible=icon]:hidden">
          <p className="font-medium text-sidebar-foreground">Plan Enterprise</p>
          <p className="mt-0.5 text-muted-foreground">
            148 de 200 propiedades activas
          </p>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
