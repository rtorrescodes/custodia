import {
  Building2,
  DollarSign,
  Wrench,
  ShieldAlert,
  TrendingUp,
  ArrowUpRight,
} from 'lucide-react'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { Kpi } from '@/lib/data'
import { formatMoney, formatMoneyCompact } from '@/lib/format'

export function KpiCards({ kpi }: { kpi: Kpi }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Total de Propiedades
          </CardTitle>
          <div className="flex size-8 items-center justify-center rounded-md bg-muted text-muted-foreground">
            <Building2 className="size-4" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-semibold tracking-tight tabular-nums">
            {kpi.totalProperties}
          </div>
          <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
            <TrendingUp className="size-3 text-success" />
            <span className="font-medium text-success">
              +{kpi.propertiesDelta}
            </span>
            nuevas este mes
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Ingresos del Mes
          </CardTitle>
          <div className="flex size-8 items-center justify-center rounded-md bg-muted text-muted-foreground">
            <DollarSign className="size-4" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-semibold tracking-tight tabular-nums">
            {formatMoneyCompact(kpi.monthlyRevenueUsd, 'USD')}
          </div>
          <div className="mt-1 flex items-center justify-between">
            <p className="text-xs text-muted-foreground tabular-nums">
              {formatMoneyCompact(kpi.monthlyRevenueMxn, 'MXN')} MXN
            </p>
            <Badge className="gap-0.5 bg-success/12 text-success border-success/30">
              <ArrowUpRight className="size-3" />
              {kpi.revenueDeltaPct}%
            </Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Órdenes de Trabajo Pendientes
          </CardTitle>
          <div className="flex size-8 items-center justify-center rounded-md bg-muted text-muted-foreground">
            <Wrench className="size-4" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-semibold tracking-tight tabular-nums">
            {kpi.pendingWorkOrders}
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            8 con prioridad alta
          </p>
        </CardContent>
      </Card>

      <Card className="border-destructive/30 bg-destructive/[0.03]">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Alertas Críticas de Seguridad
          </CardTitle>
          <div className="flex size-8 items-center justify-center rounded-md bg-destructive/10 text-destructive">
            <ShieldAlert className="size-4" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <span className="text-3xl font-semibold tracking-tight tabular-nums text-destructive">
              {kpi.criticalSecurityAlerts}
            </span>
            <Badge variant="destructive" className="h-5">
              Requiere acción
            </Badge>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            Última: acceso no autorizado en Villa Coral 12
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
