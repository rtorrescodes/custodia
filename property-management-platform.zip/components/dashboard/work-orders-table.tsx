import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardAction,
} from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { cn } from '@/lib/utils'
import type { WorkOrder } from '@/lib/data'
import {
  formatMoney,
  workOrderStatusLabel,
  workOrderStatusClass,
} from '@/lib/format'

export function WorkOrdersTable({ orders }: { orders: WorkOrder[] }) {
  return (
    <Card>
      <CardHeader className="border-b pb-4">
        <CardTitle>Órdenes de Trabajo Recientes</CardTitle>
        <CardDescription>
          Últimas solicitudes de mantenimiento en el portafolio
        </CardDescription>
        <CardAction>
          <Button variant="outline" size="sm" render={<Link href="/mantenimiento" />}>
            Ver todas
            <ArrowUpRight data-icon="inline-end" />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent className="px-0">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="pl-6">ID</TableHead>
              <TableHead>Propiedad</TableHead>
              <TableHead>Asignado a</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="pr-6 text-right">Costo</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell className="pl-6 font-mono text-xs font-medium">
                  {order.id}
                </TableCell>
                <TableCell className="font-medium">{order.property}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Avatar className="size-6">
                      <AvatarFallback className="bg-secondary text-[10px] text-secondary-foreground">
                        {order.assigneeInitials}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-muted-foreground">
                      {order.assignee}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={cn(workOrderStatusClass[order.status])}
                  >
                    {workOrderStatusLabel[order.status]}
                  </Badge>
                </TableCell>
                <TableCell className="pr-6 text-right font-medium tabular-nums">
                  {formatMoney(order.cost, order.currency)}
                  <span className="ml-1 text-xs text-muted-foreground">
                    {order.currency}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
