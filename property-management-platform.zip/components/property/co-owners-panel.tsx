import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import type { CoOwner } from '@/lib/data'

export function CoOwnersPanel({ coOwners }: { coOwners: CoOwner[] }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Copropietarios</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        {coOwners.map((owner) => (
          <div key={owner.id} className="flex flex-col gap-1.5">
            <div className="flex items-center gap-3">
              <Avatar className="size-8">
                <AvatarFallback className="bg-secondary text-xs text-secondary-foreground">
                  {owner.initials}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{owner.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {owner.email}
                </p>
              </div>
              <span className="text-sm font-semibold tabular-nums">
                {owner.sharePct}%
              </span>
            </div>
            <div
              className="h-1.5 w-full overflow-hidden rounded-full bg-muted"
              role="presentation"
            >
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${owner.sharePct}%` }}
              />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
