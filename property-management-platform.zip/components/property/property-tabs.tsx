'use client'

import { ArrowDownLeft, ArrowUpRight } from 'lucide-react'

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import type { MaintenanceEntry, LedgerEntry } from '@/lib/data'
import {
  formatMoney,
  formatDate,
  workOrderStatusLabel,
  workOrderStatusClass,
} from '@/lib/format'

interface PropertyTabsProps {
  maintenanceHistory: MaintenanceEntry[]
  ledger: LedgerEntry[]
}

export function PropertyTabs({
  maintenanceHistory,
  ledger,
}: PropertyTabsProps) {
  return (
    <Tabs defaultValue="mantenimiento">
      <TabsList>
        <TabsTrigger value="mantenimiento">
          Historial de Mantenimiento
        </TabsTrigger>
        <TabsTrigger value="ledger">Ledger Financiero</TabsTrigger>
      </TabsList>

      <TabsContent value="mantenimiento">
        <Card className="py-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="pl-4">Fecha</TableHead>
                <TableHead>Descripción</TableHead>
                <TableHead>Proveedor</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead className="pr-4 text-right">Costo</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {maintenanceHistory.map((entry) => (
                <TableRow key={entry.id}>
                  <TableCell className="pl-4 whitespace-nowrap text-muted-foreground tabular-nums">
                    {formatDate(entry.date)}
                  </TableCell>
                  <TableCell className="font-medium">{entry.title}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {entry.vendor}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={cn(workOrderStatusClass[entry.status])}
                    >
                      {workOrderStatusLabel[entry.status]}
                    </Badge>
                  </TableCell>
                  <TableCell className="pr-4 text-right font-medium tabular-nums">
                    {formatMoney(entry.cost, entry.currency)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </TabsContent>

      <TabsContent value="ledger">
        <Card className="py-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="pl-4">Fecha</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Categoría</TableHead>
                <TableHead>Descripción</TableHead>
                <TableHead className="pr-4 text-right">Monto</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ledger.map((entry) => {
                const isIncome = entry.type === 'ingreso'
                return (
                  <TableRow key={entry.id}>
                    <TableCell className="pl-4 whitespace-nowrap text-muted-foreground tabular-nums">
                      {formatDate(entry.date)}
                    </TableCell>
                    <TableCell>
                      <span
                        className={cn(
                          'inline-flex items-center gap-1 text-xs font-medium',
                          isIncome ? 'text-success' : 'text-muted-foreground'
                        )}
                      >
                        {isIncome ? (
                          <ArrowDownLeft className="size-3.5" />
                        ) : (
                          <ArrowUpRight className="size-3.5" />
                        )}
                        {isIncome ? 'Ingreso' : 'Egreso'}
                      </span>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {entry.category}
                    </TableCell>
                    <TableCell className="font-medium">
                      {entry.description}
                    </TableCell>
                    <TableCell
                      className={cn(
                        'pr-4 text-right font-medium tabular-nums',
                        isIncome && 'text-success'
                      )}
                    >
                      {isIncome ? '+' : '−'}
                      {formatMoney(entry.amount, entry.currency)}
                      <span className="ml-1 text-xs font-normal text-muted-foreground">
                        {entry.currency}
                      </span>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </Card>
      </TabsContent>
    </Tabs>
  )
}
