import { CheckCircle2, AlertTriangle, CircleSlash, Plug } from 'lucide-react'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import type { Integration, IntegrationStatus } from '@/lib/data'

const statusConfig: Record<
  IntegrationStatus,
  { label: string; icon: typeof CheckCircle2; className: string; dot: string }
> = {
  conectado: {
    label: 'Conectado',
    icon: CheckCircle2,
    className: 'bg-success/12 text-success border-success/30',
    dot: 'bg-success',
  },
  error: {
    label: 'Error',
    icon: AlertTriangle,
    className: 'bg-destructive/10 text-destructive border-destructive/30',
    dot: 'bg-destructive',
  },
  desconectado: {
    label: 'Desconectado',
    icon: CircleSlash,
    className: 'bg-muted text-muted-foreground border-border',
    dot: 'bg-muted-foreground',
  },
}

export function IntegrationsPanel({
  integrations,
}: {
  integrations: Integration[]
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Plug className="size-4 text-muted-foreground" />
          Integraciones Activas
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-2.5">
        {integrations.map((integration) => {
          const config = statusConfig[integration.status]
          return (
            <div
              key={integration.provider}
              className="flex items-start gap-3 rounded-lg border border-border p-3"
            >
              <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-secondary text-sm font-semibold text-secondary-foreground">
                {integration.provider.slice(0, 2)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium">{integration.provider}</p>
                  <span
                    className={cn(
                      'size-1.5 rounded-full',
                      config.dot
                    )}
                    aria-hidden
                  />
                </div>
                <p className="truncate text-xs text-muted-foreground">
                  {integration.description}
                </p>
                {integration.lastSync ? (
                  <p className="mt-0.5 text-[11px] text-muted-foreground">
                    Última sincronización: {integration.lastSync}
                  </p>
                ) : null}
              </div>
              <Badge variant="outline" className={cn('gap-1', config.className)}>
                <config.icon className="size-3" />
                {config.label}
              </Badge>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
