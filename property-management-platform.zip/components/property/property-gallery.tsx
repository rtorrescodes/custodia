'use client'

import { useState } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { PropertyPhoto } from '@/lib/data'

export function PropertyGallery({ photos }: { photos: PropertyPhoto[] }) {
  const [active, setActive] = useState(0)

  const go = (dir: -1 | 1) =>
    setActive((prev) => (prev + dir + photos.length) % photos.length)

  return (
    <div className="flex flex-col gap-3">
      <div className="group relative aspect-[16/10] overflow-hidden rounded-lg bg-muted">
        <Image
          src={photos[active].src || '/placeholder.svg'}
          alt={photos[active].alt}
          fill
          className="object-cover"
          sizes="(max-width: 1024px) 100vw, 66vw"
          priority
        />
        <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-black/50 to-transparent p-3">
          <span className="text-xs font-medium text-white">
            {active + 1} / {photos.length}
          </span>
          <div className="flex gap-1.5">
            <Button
              size="icon-sm"
              variant="secondary"
              className="rounded-full opacity-0 transition-opacity group-hover:opacity-100"
              onClick={() => go(-1)}
              aria-label="Foto anterior"
            >
              <ChevronLeft />
            </Button>
            <Button
              size="icon-sm"
              variant="secondary"
              className="rounded-full opacity-0 transition-opacity group-hover:opacity-100"
              onClick={() => go(1)}
              aria-label="Foto siguiente"
            >
              <ChevronRight />
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {photos.map((photo, i) => (
          <button
            key={photo.src}
            type="button"
            onClick={() => setActive(i)}
            className={cn(
              'relative aspect-[16/10] overflow-hidden rounded-md ring-1 ring-border transition-all',
              i === active
                ? 'ring-2 ring-primary'
                : 'opacity-70 hover:opacity-100'
            )}
            aria-label={`Ver ${photo.alt}`}
            aria-current={i === active}
          >
            <Image
              src={photo.src || '/placeholder.svg'}
              alt={photo.alt}
              fill
              className="object-cover"
              sizes="20vw"
            />
          </button>
        ))}
      </div>
    </div>
  )
}
