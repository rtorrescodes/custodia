'use client'

import { useState } from 'react'
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  FileText,
  Check,
  Inbox,
  AlertCircle,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@/components/ui/empty'
import { cn } from '@/lib/utils'
import type { LedgerEntry, OwnerLedgerData } from '@/lib/data'
import { formatMoney, formatDate } from '@/lib/format'

type ViewState = 'success' | 'loading' | 'empty' | 'error'

// expenses at or above this MXN-equivalent threshold need explicit approval
const APPROVAL_THRESHOLD = 3000

const states: { value: ViewState; label: string }[] = [
  { value: 'success', label: 'Con datos' },
  { value: 'loading', label: 'Cargando' },
  { value: 'empty', label: 'Vacío' },
  { value: 'error', label: 'Error' },
]

export function OwnerLedger({ data }: { data: OwnerLedgerData }) {
  const [view, setView] = useState<ViewState>('success')
  const [approved, setApproved] = useState<Record<string, boolean>>({})

  const approve = (id: string) =>
    setApproved((prev) => ({ ...prev, [id]: true }))

  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col gap-6 px-4 py-6 md:px-6 md:py-8">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <p className="text-sm text-muted-foreground">Estado de cuenta</p>
          <h1 className="text-2xl font-semibold tracking-tight text-balance">
            {data.propertyName}
          </h1>
        </div>
        {/* Demo-only state preview switcher */}
        <div className="flex flex-wrap gap-1 rounded-lg border border-border bg-card p-1">
          {states.map((s) => (
            <Button
              key={s.value}
              size="sm"
              variant={view === s.value ? 'secondary' : 'ghost'}
              className="h-7 text-xs"
              onClick={() => setView(s.value)}
            >
              {s.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Summary cards */}
      {view === 'loading' ? (
        <SummarySkeleton />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Card className="bg-primary text-primary-foreground">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-primary-foreground/80">
                Saldo Actual
              </CardTitle>
              <Wallet className="size-4 text-primary-foreground/70" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-semibold tracking-tight tabular-nums">
                {formatMoney(data.balance, data.balanceCurrency)}
              </p>
              <p className="mt-0.5 text-xs text-primary-foreground/70">
                {data.balanceCurrency} · disponible
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Ingresos del Mes
              </CardTitle>
              <ArrowDownLeft className="size-4 text-success" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-semibold tracking-tight tabular-nums text-success">
                {formatMoney(data.monthIncome, 'USD')}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">USD</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Egresos del Mes
              </CardTitle>
              <ArrowUpRight className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-semibold tracking-tight tabular-nums">
                {formatMoney(data.monthExpense, 'MXN')}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">MXN</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Transactions */}
      <Card className={cn(view === 'success' && 'py-0', 'overflow-visible')}>
        {view !== 'success' && view !== 'loading' ? null : (
          <CardHeader
            className={cn(
              'flex flex-row items-center justify-between',
              view === 'success' && 'border-b py-4'
            )}
          >
            <CardTitle className="text-base">Transacciones</CardTitle>
            <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <ShieldCheck className="size-3.5 text-success" />
              Trust accounting verificado
            </span>
          </CardHeader>
        )}

        {view === 'loading' ? (
          <CardContent className="flex flex-col gap-3 pb-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <TransactionSkeleton key={i} />
            ))}
          </CardContent>
        ) : view === 'error' ? (
          <CardContent className="py-4">
            <Alert variant="destructive">
              <AlertCircle />
              <AlertTitle>No pudimos cargar tu estado de cuenta</AlertTitle>
              <AlertDescription>
                Ocurrió un problema al obtener tus transacciones. Revisa tu
                conexión e inténtalo de nuevo.
              </AlertDescription>
            </Alert>
            <Button
              variant="outline"
              size="sm"
              className="mt-3"
              onClick={() => setView('loading')}
            >
              <RefreshCw data-icon="inline-start" />
              Reintentar
            </Button>
          </CardContent>
        ) : view === 'empty' ? (
          <CardContent className="py-4">
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <Inbox />
                </EmptyMedia>
                <EmptyTitle>Aún no hay transacciones</EmptyTitle>
                <EmptyDescription>
                  Cuando se registren ingresos o egresos en tu propiedad,
                  aparecerán aquí con su comprobante.
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button variant="outline" size="sm">
                  Contactar a mi administrador
                </Button>
              </EmptyContent>
            </Empty>
          </CardContent>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="pl-6">Fecha</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Categoría</TableHead>
                    <TableHead>Descripción</TableHead>
                    <TableHead className="text-right">Monto</TableHead>
                    <TableHead className="pr-6 text-right">Recibo</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.transactions.map((tx) => (
                    <TransactionRow
                      key={tx.id}
                      tx={tx}
                      approved={!!approved[tx.id]}
                      onApprove={() => approve(tx.id)}
                    />
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile cards */}
            <div className="flex flex-col divide-y divide-border md:hidden">
              {data.transactions.map((tx) => (
                <TransactionCard
                  key={tx.id}
                  tx={tx}
                  approved={!!approved[tx.id]}
                  onApprove={() => approve(tx.id)}
                />
              ))}
            </div>
          </>
        )}
      </Card>
    </div>
  )
}

function needsApproval(tx: LedgerEntry, approved: boolean) {
  return (
    tx.type === 'egreso' &&
    tx.approvalRequired &&
    tx.approvalStatus === 'pendiente' &&
    tx.amount >= APPROVAL_THRESHOLD &&
    !approved
  )
}

function AmountCell({ tx }: { tx: LedgerEntry }) {
  const isIncome = tx.type === 'ingreso'
  return (
    <span
      className={cn(
        'font-medium tabular-nums',
        isIncome && 'text-success'
      )}
    >
      {isIncome ? '+' : '−'}
      {formatMoney(tx.amount, tx.currency)}
      <span className="ml-1 text-xs font-normal text-muted-foreground">
        {tx.currency}
      </span>
    </span>
  )
}

function TypeBadge({ tx }: { tx: LedgerEntry }) {
  const isIncome = tx.type === 'ingreso'
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 text-xs font-medium',
        isIncome ? 'text-success' : 'text-muted-foreground'
      )}
    >
      {isIncome ? (
        <ArrowDownLeft className="size-3.5" />
      ) : (
        <ArrowUpRight className="size-3.5" />
      )}
      {isIncome ? 'Ingreso' : 'Egreso'}
    </span>
  )
}

function ReceiptButton({ tx }: { tx: LedgerEntry }) {
  if (!tx.hasReceipt) {
    return <span className="text-xs text-muted-foreground">Sin recibo</span>
  }
  return (
    <Button variant="ghost" size="sm" className="h-7">
      <FileText data-icon="inline-start" />
      Ver
    </Button>
  )
}

function TransactionRow({
  tx,
  approved,
  onApprove,
}: {
  tx: LedgerEntry
  approved: boolean
  onApprove: () => void
}) {
  return (
    <TableRow>
      <TableCell className="pl-6 whitespace-nowrap text-muted-foreground tabular-nums">
        {formatDate(tx.date)}
      </TableCell>
      <TableCell>
        <TypeBadge tx={tx} />
      </TableCell>
      <TableCell className="text-muted-foreground">{tx.category}</TableCell>
      <TableCell className="max-w-xs">
        <span className="font-medium">{tx.description}</span>
        {needsApproval(tx, approved) ? (
          <Button
            size="sm"
            className="ml-2 h-6 bg-warning text-warning-foreground hover:bg-warning/90"
            onClick={onApprove}
          >
            Aprobar Gasto
          </Button>
        ) : approved && tx.approvalRequired ? (
          <Badge className="ml-2 gap-1 bg-success/12 text-success border-success/30">
            <Check className="size-3" />
            Aprobado
          </Badge>
        ) : null}
      </TableCell>
      <TableCell className="text-right">
        <AmountCell tx={tx} />
      </TableCell>
      <TableCell className="pr-6 text-right">
        <ReceiptButton tx={tx} />
      </TableCell>
    </TableRow>
  )
}

function TransactionCard({
  tx,
  approved,
  onApprove,
}: {
  tx: LedgerEntry
  approved: boolean
  onApprove: () => void
}) {
  return (
    <div className="flex flex-col gap-2 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex flex-col gap-0.5">
          <span className="font-medium">{tx.description}</span>
          <span className="text-xs text-muted-foreground">
            {tx.category} · {formatDate(tx.date)}
          </span>
        </div>
        <AmountCell tx={tx} />
      </div>
      <div className="flex items-center justify-between">
        <TypeBadge tx={tx} />
        <ReceiptButton tx={tx} />
      </div>
      {needsApproval(tx, approved) ? (
        <Button
          size="sm"
          className="mt-1 w-full bg-warning text-warning-foreground hover:bg-warning/90"
          onClick={onApprove}
        >
          Aprobar Gasto
        </Button>
      ) : approved && tx.approvalRequired ? (
        <Badge className="mt-1 w-fit gap-1 bg-success/12 text-success border-success/30">
          <Check className="size-3" />
          Aprobado
        </Badge>
      ) : null}
    </div>
  )
}

function SummarySkeleton() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <Card key={i}>
          <CardHeader className="pb-2">
            <Skeleton className="h-4 w-28" />
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            <Skeleton className="h-7 w-32" />
            <Skeleton className="h-3 w-16" />
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function TransactionSkeleton() {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex flex-col gap-1.5">
        <Skeleton className="h-4 w-40" />
        <Skeleton className="h-3 w-24" />
      </div>
      <Skeleton className="h-4 w-20" />
    </div>
  )
}
