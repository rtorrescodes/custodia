'use client'

import { Bell, Search, ChevronDown, LogOut, User, Settings } from 'lucide-react'

import { SidebarTrigger } from '@/components/ui/sidebar'
import { Separator } from '@/components/ui/separator'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface AppHeaderProps {
  managerName: string
  breadcrumb?: string
}

export function AppHeader({ managerName, breadcrumb }: AppHeaderProps) {
  const initials = managerName
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0])
    .join('')

  return (
    <header className="sticky top-0 z-20 flex h-16 shrink-0 items-center gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-sm md:px-6">
      <SidebarTrigger className="-ml-1" />
      <Separator orientation="vertical" className="mr-1 h-5" />

      {breadcrumb ? (
        <span className="hidden text-sm font-medium text-muted-foreground md:inline">
          {breadcrumb}
        </span>
      ) : null}

      <div className="relative ml-auto w-full max-w-md md:ml-2 md:mr-auto">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Buscar propiedades, órdenes, dueños…"
          className="h-9 pl-9"
          aria-label="Búsqueda global"
        />
      </div>

      <div className="flex items-center gap-1">
        <DropdownMenu>
          <DropdownMenuTrigger
            render={
              <Button
                variant="ghost"
                size="icon-sm"
                className="relative"
                aria-label="Notificaciones"
              />
            }
          >
            <Bell />
            <span className="absolute right-1 top-1 size-2 rounded-full bg-destructive ring-2 ring-background" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel>Notificaciones</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem className="flex-col items-start gap-0.5 py-2">
                <span className="flex w-full items-center gap-2 text-sm font-medium">
                  Alerta de seguridad crítica
                  <Badge variant="destructive" className="ml-auto">
                    Crítica
                  </Badge>
                </span>
                <span className="text-xs text-muted-foreground">
                  RAVSIS reportó acceso no autorizado en Villa Coral 12
                </span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex-col items-start gap-0.5 py-2">
                <span className="text-sm font-medium">
                  Gasto pendiente de aprobación
                </span>
                <span className="text-xs text-muted-foreground">
                  Reparación de tubería · $4,800 MXN
                </span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex-col items-start gap-0.5 py-2">
                <span className="text-sm font-medium">
                  Nueva orden de trabajo
                </span>
                <span className="text-xs text-muted-foreground">
                  OT-4821 asignada a Miguel Ángel Torres
                </span>
              </DropdownMenuItem>
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger
            render={
              <Button variant="ghost" className="h-9 gap-2 px-1.5 md:pr-2.5" />
            }
          >
            <Avatar className="size-7">
              <AvatarFallback className="bg-primary text-xs text-primary-foreground">
                {initials}
              </AvatarFallback>
            </Avatar>
            <span className="hidden text-sm font-medium md:inline">
              {managerName}
            </span>
            <ChevronDown className="hidden size-4 text-muted-foreground md:inline" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>
              <div className="flex flex-col">
                <span className="text-sm font-medium">{managerName}</span>
                <span className="text-xs font-normal text-muted-foreground">
                  Administradora
                </span>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem>
                <User />
                Mi perfil
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings />
                Preferencias
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive">
              <LogOut />
              Cerrar sesión
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
