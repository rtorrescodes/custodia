import Link from 'next/link'
import { ShieldCheck, ArrowLeft } from 'lucide-react'

import { OwnerLedger } from '@/components/portal/owner-ledger'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { getOwnerLedger } from '@/lib/data'

export default async function OwnerPortalPage() {
  const data = await getOwnerLedger()

  const initials = data.ownerName
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0])
    .join('')

  return (
    <div className="min-h-svh bg-background">
      <header className="sticky top-0 z-20 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="mx-auto flex h-16 w-full max-w-4xl items-center gap-3 px-4 md:px-6">
          <div className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <ShieldCheck className="size-4" />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-tight">
              Portal de Dueño
            </span>
            <span className="text-xs text-muted-foreground">Atrio</span>
          </div>
          <div className="ml-auto flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              render={<Link href="/" />}
              className="hidden sm:inline-flex"
            >
              <ArrowLeft data-icon="inline-start" />
              Vista admin
            </Button>
            <div className="flex items-center gap-2">
              <Avatar className="size-8">
                <AvatarFallback className="bg-secondary text-xs text-secondary-foreground">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <span className="hidden text-sm font-medium sm:inline">
                {data.ownerName}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main>
        <OwnerLedger data={data} />
      </main>
    </div>
  )
}
