import Link from 'next/link'
import Image from 'next/image'
import { MapPin, ArrowUpRight } from 'lucide-react'

import { AppShell } from '@/components/app-shell'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { getDashboardData } from '@/lib/data'
import { cn } from '@/lib/utils'

const properties = [
  {
    id: 'prop-001',
    name: 'Villa Coral 12',
    fraccionamiento: 'Bahía Marina',
    city: 'Nuevo Vallarta',
    status: 'ocupada' as const,
    image: '/properties/casa-exterior.png',
  },
  {
    id: 'prop-002',
    name: 'Residencia Palma 3',
    fraccionamiento: 'Palmares',
    city: 'Puerto Vallarta',
    status: 'disponible' as const,
    image: '/properties/casa-sala.png',
  },
  {
    id: 'prop-003',
    name: 'Casa Encino 8',
    fraccionamiento: 'Bosques',
    city: 'Guadalajara',
    status: 'mantenimiento' as const,
    image: '/properties/amenidad-alberca.png',
  },
]

const statusLabel = {
  ocupada: 'Ocupada',
  disponible: 'Disponible',
  mantenimiento: 'En mantenimiento',
}

const statusClass = {
  ocupada: 'bg-success/12 text-success border-success/30',
  disponible: 'bg-info/12 text-info border-info/30',
  mantenimiento: 'bg-warning/15 text-warning-foreground border-warning/30',
}

export default async function PropertiesListPage() {
  const dashboard = await getDashboardData()

  return (
    <AppShell managerName={dashboard.managerName} breadcrumb="Propiedades">
      <div className="flex flex-col gap-6 p-4 md:p-6">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Propiedades</h1>
          <p className="text-sm text-muted-foreground">
            {dashboard.kpi.totalProperties} propiedades en el portafolio
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {properties.map((p) => (
            <Link key={p.id} href={`/propiedades/${p.id}`} className="group">
              <Card className="overflow-hidden py-0 transition-shadow hover:shadow-md">
                <div className="relative aspect-[16/10] bg-muted">
                  <Image
                    src={p.image || '/placeholder.svg'}
                    alt={p.name}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                    sizes="(max-width: 1024px) 100vw, 33vw"
                  />
                  <Badge
                    variant="outline"
                    className={cn(
                      'absolute left-3 top-3 backdrop-blur-sm',
                      statusClass[p.status]
                    )}
                  >
                    {statusLabel[p.status]}
                  </Badge>
                </div>
                <CardContent className="flex items-center justify-between py-4">
                  <div className="flex flex-col gap-0.5">
                    <p className="font-medium">{p.name}</p>
                    <p className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="size-3" />
                      {p.fraccionamiento} · {p.city}
                    </p>
                  </div>
                  <ArrowUpRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
