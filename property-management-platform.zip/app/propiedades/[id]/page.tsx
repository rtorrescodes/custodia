import { notFound } from 'next/navigation'
import {
  MapPin,
  Plus,
  BedDouble,
  Bath,
  Ruler,
  Home,
  CheckCircle2,
} from 'lucide-react'

import { AppShell } from '@/components/app-shell'
import { PropertyGallery } from '@/components/property/property-gallery'
import { CoOwnersPanel } from '@/components/property/co-owners-panel'
import { IntegrationsPanel } from '@/components/property/integrations-panel'
import { PropertyTabs } from '@/components/property/property-tabs'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { getProperty, getDashboardData } from '@/lib/data'
import { cn } from '@/lib/utils'

const statusLabel = {
  ocupada: 'Ocupada',
  disponible: 'Disponible',
  mantenimiento: 'En mantenimiento',
} as const

const statusClass = {
  ocupada: 'bg-success/12 text-success border-success/30',
  disponible: 'bg-info/12 text-info border-info/30',
  mantenimiento: 'bg-warning/15 text-warning-foreground border-warning/30',
} as const

export default async function PropertyPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const [property, dashboard] = await Promise.all([
    getProperty(id),
    getDashboardData(),
  ])

  if (!property) notFound()

  const specs = [
    { icon: Home, label: property.type },
    { icon: BedDouble, label: `${property.bedrooms} recámaras` },
    { icon: Bath, label: `${property.bathrooms} baños` },
    { icon: Ruler, label: `${property.areaM2} m²` },
  ]

  return (
    <AppShell managerName={dashboard.managerName} breadcrumb="Propiedades">
      <div className="flex flex-col gap-6 p-4 md:p-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex flex-col gap-2">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl font-semibold tracking-tight text-balance">
                {property.name}
              </h1>
              <Badge
                variant="outline"
                className={cn(statusClass[property.status])}
              >
                {statusLabel[property.status]}
              </Badge>
            </div>
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="size-4 shrink-0" />
              {property.address} · {property.fraccionamiento}
            </p>
          </div>
          <Button>
            <Plus data-icon="inline-start" />
            Crear Orden de Trabajo
          </Button>
        </div>

        {/* Main grid */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Left column */}
          <div className="flex flex-col gap-6 lg:col-span-2">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Información general</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-4">
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {specs.map((spec) => (
                    <div key={spec.label} className="flex flex-col gap-1">
                      <spec.icon className="size-4 text-muted-foreground" />
                      <span className="text-sm font-medium">{spec.label}</span>
                    </div>
                  ))}
                </div>
                <Separator />
                <dl className="grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
                  <div className="flex flex-col gap-0.5">
                    <dt className="text-xs text-muted-foreground">Ciudad</dt>
                    <dd className="font-medium">{property.city}</dd>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <dt className="text-xs text-muted-foreground">
                      Fraccionamiento
                    </dt>
                    <dd className="font-medium">{property.fraccionamiento}</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Galería</CardTitle>
              </CardHeader>
              <CardContent>
                <PropertyGallery photos={property.photos} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Amenidades</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {property.amenities.map((amenity) => (
                    <li
                      key={amenity}
                      className="flex items-center gap-2 text-sm"
                    >
                      <CheckCircle2 className="size-4 shrink-0 text-success" />
                      {amenity}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Right column */}
          <div className="flex flex-col gap-6">
            <CoOwnersPanel coOwners={property.coOwners} />
            <IntegrationsPanel integrations={property.integrations} />
          </div>
        </div>

        {/* Bottom tabs */}
        <PropertyTabs
          maintenanceHistory={property.maintenanceHistory}
          ledger={property.ledger}
        />
      </div>
    </AppShell>
  )
}
