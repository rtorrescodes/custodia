import { Wrench } from 'lucide-react'

import { AppShell } from '@/components/app-shell'
import { SectionPlaceholder } from '@/components/section-placeholder'
import { getDashboardData } from '@/lib/data'

export default async function MantenimientoPage() {
  const dashboard = await getDashboardData()
  return (
    <AppShell managerName={dashboard.managerName} breadcrumb="Mantenimiento">
      <SectionPlaceholder
        title="Mantenimiento"
        description="Aquí administrarás todas las órdenes de trabajo, proveedores y calendarios de mantenimiento preventivo."
        icon={Wrench}
      />
    </AppShell>
  )
}
