import { Settings } from 'lucide-react'

import { AppShell } from '@/components/app-shell'
import { SectionPlaceholder } from '@/components/section-placeholder'
import { getDashboardData } from '@/lib/data'

export default async function ConfiguracionPage() {
  const dashboard = await getDashboardData()
  return (
    <AppShell managerName={dashboard.managerName} breadcrumb="Configuración">
      <SectionPlaceholder
        title="Configuración"
        description="Administra tu organización, usuarios, roles y preferencias de la plataforma."
        icon={Settings}
      />
    </AppShell>
  )
}
