import { Wallet } from 'lucide-react'

import { AppShell } from '@/components/app-shell'
import { SectionPlaceholder } from '@/components/section-placeholder'
import { getDashboardData } from '@/lib/data'

export default async function FinanzasPage() {
  const dashboard = await getDashboardData()
  return (
    <AppShell managerName={dashboard.managerName} breadcrumb="Finanzas">
      <SectionPlaceholder
        title="Finanzas"
        description="Consolidado de ingresos, egresos y trust accounting de todo el portafolio, con reportes multi-moneda."
        icon={Wallet}
      />
    </AppShell>
  )
}
