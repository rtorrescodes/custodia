import { Plug } from 'lucide-react'

import { AppShell } from '@/components/app-shell'
import { SectionPlaceholder } from '@/components/section-placeholder'
import { getDashboardData } from '@/lib/data'

export default async function IntegracionesPage() {
  const dashboard = await getDashboardData()
  return (
    <AppShell managerName={dashboard.managerName} breadcrumb="Integraciones">
      <SectionPlaceholder
        title="Integraciones"
        description="Conecta y monitorea servicios externos como Alddea y RAVSIS para sincronizar cuotas y seguridad."
        icon={Plug}
      />
    </AppShell>
  )
}
