import { AppShell } from '@/components/app-shell'
import { KpiCards } from '@/components/dashboard/kpi-cards'
import { WorkOrdersTable } from '@/components/dashboard/work-orders-table'
import { getDashboardData } from '@/lib/data'

export default async function DashboardPage() {
  const data = await getDashboardData()

  return (
    <AppShell managerName={data.managerName} breadcrumb="Inicio">
      <div className="flex flex-col gap-6 p-4 md:p-6">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight text-balance">
            Buen día, {data.managerName.split(' ')[0]}
          </h1>
          <p className="text-sm text-muted-foreground">
            Resumen ejecutivo de {data.orgName} · Agosto 2026
          </p>
        </div>

        <KpiCards kpi={data.kpi} />

        <WorkOrdersTable orders={data.recentWorkOrders} />
      </div>
    </AppShell>
  )
}
